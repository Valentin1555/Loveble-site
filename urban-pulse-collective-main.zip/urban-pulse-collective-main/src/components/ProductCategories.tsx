import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

const ProductCategories = () => {
  const { toast } = useToast();

  const handleExploreCategory = (categoryName: string) => {
    toast({
      title: `Exploring ${categoryName}! 🔥`,
      description: `Browsing our ${categoryName.toLowerCase()} collection`,
    });
  };
  const categories = [
    {
      name: "T-SHIRTS",
      description: "Premium streetwear essentials",
      image: "🔥",
      count: "24+ Styles"
    },
    {
      name: "SHORTS",
      description: "Urban comfort meets style",
      image: "⚡",
      count: "18+ Styles"
    },
    {
      name: "SNEAKERS",
      description: "Limited edition drops",
      image: "👟",
      count: "12+ Drops"
    },
    {
      name: "SOCKS",
      description: "Complete your fit",
      image: "🧦",
      count: "30+ Designs"
    },
    {
      name: "JEWELRY",
      description: "Statement pieces",
      image: "💎",
      count: "15+ Pieces"
    },
    {
      name: "FRAGRANCES",
      description: "Signature scents",
      image: "🌟",
      count: "8+ Scents"
    }
  ];

  return (
    <section id="collections" className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-black mb-4 bg-gradient-neon bg-clip-text text-transparent">
            SHOP BY CATEGORY
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover our curated collection of urban essentials, from streetwear classics to exclusive drops.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((category, index) => (
            <Card key={category.name} className="group hover:shadow-glow transition-all duration-500 transform hover:scale-105 bg-gradient-card border-border/50">
              <CardContent className="p-8 text-center">
                <div className="text-6xl mb-6 group-hover:scale-110 transition-transform duration-300">
                  {category.image}
                </div>
                <h3 className="text-2xl font-bold mb-2 text-foreground">
                  {category.name}
                </h3>
                <p className="text-muted-foreground mb-2">
                  {category.description}
                </p>
                <p className="text-sm text-primary font-semibold mb-6">
                  {category.count}
                </p>
                <Button variant="neon" className="w-full" onClick={() => handleExploreCategory(category.name)}>
                  EXPLORE
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductCategories;