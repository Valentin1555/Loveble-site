import { Instagram, Twitter, Youtube, MapPin } from "lucide-react";

const Footer = () => {
  const footerLinks = {
    Shop: ["New Arrivals", "T-Shirts", "Shorts", "Sneakers", "Accessories", "Sale"],
    Company: ["About Us", "Careers", "Press", "Sustainability", "Size Guide"],
    Support: ["Contact Us", "FAQ", "Shipping", "Returns", "Track Order"],
    Legal: ["Privacy Policy", "Terms of Service", "Cookie Policy"]
  };

  return (
    <footer className="bg-background border-t border-border">
      <div className="max-w-7xl mx-auto px-4 py-16">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          {/* Brand Section */}
          <div className="lg:col-span-2">
            <h3 className="text-3xl font-black bg-gradient-primary bg-clip-text text-transparent mb-4">
              URBAN PULSE
            </h3>
            <p className="text-muted-foreground mb-6 max-w-md">
              Authentic streetwear for the urban generation. Made for those who live and breathe 
              the pulse of the city.
            </p>
            
            {/* Social Links */}
            <div className="flex space-x-4">
              <a href="#" className="p-2 bg-card rounded-lg hover:bg-primary hover:text-primary-foreground transition-colors duration-300">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="p-2 bg-card rounded-lg hover:bg-primary hover:text-primary-foreground transition-colors duration-300">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="p-2 bg-card rounded-lg hover:bg-primary hover:text-primary-foreground transition-colors duration-300">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Links Sections */}
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h4 className="font-bold text-foreground mb-4 text-sm tracking-wider">
                {title.toUpperCase()}
              </h4>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link}>
                    <a 
                      href="#" 
                      className="text-muted-foreground hover:text-primary transition-colors duration-300 text-sm"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Store Location */}
        <div className="border-t border-border pt-8 mb-8">
          <div className="flex items-center justify-center md:justify-start space-x-2 text-muted-foreground">
            <MapPin className="h-4 w-4" />
            <span className="text-sm">Flagship Store: 123 Urban Street, City Center, NY 10001</span>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-border pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-sm text-muted-foreground">
              © 2024 Urban Pulse. All rights reserved. Made with 🔥 for the streets.
            </p>
            <div className="flex space-x-6 text-sm text-muted-foreground">
              <span>Secure Payments</span>
              <span>Free Shipping $100+</span>
              <span>Easy Returns</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;