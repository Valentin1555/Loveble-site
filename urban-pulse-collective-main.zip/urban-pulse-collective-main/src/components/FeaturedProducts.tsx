import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useCart } from "@/hooks/useCart";
import { useToast } from "@/hooks/use-toast";

const FeaturedProducts = () => {
  const { addToCart } = useCart();
  const { toast } = useToast();

  const products = [
    {
      id: "1",
      name: "NEON NIGHTS TEE",
      price: 89,
      originalPrice: 120,
      badge: "LIMITED DROP",
      color: "Electric Blue",
      image: "🎨"
    },
    {
      id: "2",
      name: "URBAN CARGO SHORTS",
      price: 125,
      originalPrice: 160,
      badge: "BESTSELLER",
      color: "Shadow Black",
      image: "🏙️"
    },
    {
      id: "3",
      name: "PULSE RUNNERS",
      price: 280,
      originalPrice: 350,
      badge: "EXCLUSIVE",
      color: "Neon Cyan",
      image: "⚡"
    },
    {
      id: "4",
      name: "STREET CHAIN SET",
      price: 195,
      originalPrice: 240,
      badge: "NEW ARRIVAL",
      color: "Chrome",
      image: "🔗"
    }
  ];

  const handleAddToCart = (product: typeof products[0]) => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
    });
  };

  const handleViewAllProducts = () => {
    toast({
      title: "Coming Soon! 🚀",
      description: "Our full product catalog is launching soon",
    });
  };

  return (
    <section id="featured" className="py-20 px-4 bg-muted/20">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-black mb-4 text-foreground">
            FEATURED DROPS
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Handpicked pieces that define the urban aesthetic. Limited quantities, maximum impact.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <Card key={product.id} className="group hover:shadow-neon transition-all duration-500 transform hover:scale-105 bg-card border-border">
              <CardContent className="p-0">
                <div className="relative">
                  {/* Product Image Placeholder */}
                  <div className="aspect-square bg-gradient-card flex items-center justify-center text-8xl group-hover:scale-110 transition-transform duration-300">
                    {product.image}
                  </div>
                  
                  {/* Badge */}
                  <Badge className="absolute top-4 left-4 bg-primary text-primary-foreground font-bold">
                    {product.badge}
                  </Badge>
                </div>

                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2 text-foreground">
                    {product.name}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    {product.color}
                  </p>
                  
                  <div className="flex items-center gap-2 mb-4">
                    <span className="text-2xl font-bold text-primary">
                      ${product.price}
                    </span>
                    <span className="text-lg text-muted-foreground line-through">
                      ${product.originalPrice}
                    </span>
                  </div>

                  <Button variant="neon" className="w-full" onClick={() => handleAddToCart(product)}>
                    ADD TO CART
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button variant="hero" size="lg" onClick={handleViewAllProducts}>
            VIEW ALL PRODUCTS
          </Button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;