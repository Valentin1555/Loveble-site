import { Button } from "@/components/ui/button";
import { smoothScrollToSection } from "@/utils/scrollUtils";

const BrandStory = () => {
  return (
    <section id="about" className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl md:text-6xl font-black mb-8 bg-gradient-primary bg-clip-text text-transparent">
              THE URBAN PULSE STORY
            </h2>
            <div className="space-y-6 text-lg text-muted-foreground">
              <p>
                Born in the heart of the city, Urban Pulse emerged from the intersection of street culture, 
                art, and authentic self-expression. We're not just a brand – we're a movement.
              </p>
              <p>
                Every piece in our collection tells a story of urban life, from the neon-lit streets 
                to the underground scenes that shape modern culture. We design for those who dare to 
                stand out, who find beauty in the raw energy of city living.
              </p>
              <p>
                Our mission is simple: create streetwear that doesn't just look good, but feels like 
                an extension of your identity. Each drop is limited, each design is intentional, 
                and every customer becomes part of our urban family.
              </p>
            </div>
            <div className="mt-8">
              <Button variant="street" size="lg" onClick={() => smoothScrollToSection('newsletter')}>
                JOIN THE MOVEMENT
              </Button>
            </div>
          </div>

          <div className="relative">
            {/* Animated Brand Elements */}
            <div className="relative aspect-square">
              <div className="absolute inset-0 bg-gradient-hero rounded-3xl opacity-20 animate-pulse"></div>
              <div className="absolute inset-8 bg-gradient-neon rounded-2xl opacity-30 animate-pulse delay-500"></div>
              <div className="absolute inset-16 bg-card rounded-xl flex items-center justify-center">
                <div className="text-center">
                  <div className="text-6xl mb-4">🏙️</div>
                  <h3 className="text-2xl font-bold text-foreground mb-2">EST. 2024</h3>
                  <p className="text-muted-foreground">AUTHENTIC STREETWEAR</p>
                </div>
              </div>
            </div>

            {/* Floating Stats */}
            <div className="absolute -top-8 -right-8 bg-card rounded-lg p-4 shadow-glow">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">50K+</div>
                <div className="text-sm text-muted-foreground">Community</div>
              </div>
            </div>

            <div className="absolute -bottom-8 -left-8 bg-card rounded-lg p-4 shadow-glow">
              <div className="text-center">
                <div className="text-2xl font-bold text-secondary">100+</div>
                <div className="text-sm text-muted-foreground">Designs</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BrandStory;