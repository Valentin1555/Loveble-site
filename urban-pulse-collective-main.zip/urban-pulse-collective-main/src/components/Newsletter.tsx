import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

const Newsletter = () => {
  const [email, setEmail] = useState("");
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      toast({
        title: "Welcome to the Urban Pulse family! 🔥",
        description: "You'll be the first to know about new drops and exclusive releases.",
      });
      setEmail("");
    }
  };

  return (
    <section id="newsletter" className="py-20 px-4 bg-gradient-hero">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-4xl md:text-6xl font-black mb-6 text-foreground">
          STAY IN THE PULSE
        </h2>
        <p className="text-xl text-foreground/80 mb-8 max-w-2xl mx-auto">
          Get exclusive access to limited drops, street style tips, and be the first to know 
          about our latest releases. Join 50K+ urban creators worldwide.
        </p>

        <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
          <Input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="flex-1 bg-background/90 border-border text-foreground placeholder:text-muted-foreground"
            required
          />
          <Button type="submit" variant="street" size="lg">
            JOIN NOW
          </Button>
        </form>

        <div className="mt-8 flex justify-center space-x-4 text-sm text-foreground/60">
          <span>🔒 No spam, ever</span>
          <span>📱 Mobile-first updates</span>
          <span>🎁 Exclusive member perks</span>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;